Modular Terraform infrastructure.

Goal is to have two variables:

Environment: dev/sit/lbprod/prod
Region / Country: eu-west-1 for example. Perhaps by RW country?

