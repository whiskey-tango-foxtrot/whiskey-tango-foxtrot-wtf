#!/bin/bash -e
#==================================================================#
#                                  TODO                            #
#==================================================================#
# Be able to pass in extra args
# Add S3 lifecycle management

#==================================================================#
#                    This needs to be injected                     #
#==================================================================#

PROJECT=zenith
TERRAENV=$1
LAYER=$2
ACTION=$3

echo project=$PROJECT
echo terraenv=$TERRAENV
echo layer=$LAYER
echo action=$ACTION

TERRAFORMSTATELOCKFILE="${PROJECT}-${TERRAENV}-${AWS_DEFAULT_REGION}-terrastatelock"

STATE_BUCKET="${PROJECT}-${TERRAENV}-${AWS_DEFAULT_REGION}-terrastate"

STATE_FILENAME="${LAYER}-terraform.tfstate"
if [ "$LAYER" == "." ]; then
  die "Ohhh man...! I was not expecting this, you need to tell me the layer!"
fi

echo statebucket=$STATE_BUCKET
echo statefile=$STATE_FILENAME

# Set path
CWD=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
CONFIG_DIR="${CWD}/environments/$TERRAENV"
# TERRAENV_CONFIG="${CONFIG_DIR}/${TERRAENV}.tfvars"
TERRAENV_LAYER_CONFIG="${CONFIG_DIR}/${LAYER}.tfvars"
TERRAENV_CONFIG="${CONFIG_DIR}/shared.tfvars"
# TERRAENV_LAYER_CONFIG="${CONFIG_DIR}/dev.tfvars"
TERRAENV_SUBENV="$CONFIG_DIR/dev/rds.tfvars"      #WIP
PLAN_PATH="${CWD}/${LAYER}/.terraplan"
TERRAFORM_PATH="${CWD}/${LAYER}"

echo terraformpath=$TERRAFORM_PATH

VAR_ITEMS=("-var-file=${TERRAENV_CONFIG} -var-file=${TERRAENV_LAYER_CONFIG}")
#VAR_ITEMS=("-var-file=${TERRAENV_CONFIG}")

#==================================================================#
#                            Functions                             #
#==================================================================#
die() {
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo $@ | sed  -e :a -e 's/^.\{1,77\}$/ & /;ta'
  echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  >&2 
   "Error: $*"
  exit 1
}

usage(){
  echo "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=++"
  echo "Usage: $0 <>"
  echo "./tf.sh nonprod vpc plan"
  echo "./tf.sh nonprod vpc apply"
  echo "./tf.sh nonprod vpc destroy"
  1>&2
  echo "+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=+=++"
  exit 1
}

create_state_bucket() {
  aws s3 ls s3://${STATE_BUCKET} >/dev/null 2>&1 \
  || aws s3 mb s3://${STATE_BUCKET} --region ${AWS_DEFAULT_REGION} \
  || die "Ohhh man...! Unable to create bucket ${STATE_BUCKET}  with command: aws s3 mb s3://${STATE_BUCKET} --region ${AWS_DEFAULT_REGION}"
}

enable_bucket_versioning() {
  aws s3api get-bucket-versioning --bucket ${STATE_BUCKET} \
  | grep -q Enabled \
  || aws \
    s3api put-bucket-versioning \
    --bucket ${STATE_BUCKET} \
    --versioning-configuration Status=Enabled \
  || die "Ohhh man...! Versioning is not enabled for ${STATE_BUCKET}"
}

create_lock_table() {
  aws \
    dynamodb list-tables | grep -q ${TERRAFORMSTATELOCKFILE} \
    || aws dynamodb create-table \
      --table-name ${TERRAFORMSTATELOCKFILE} \
      --attribute-definitions AttributeName=LockID,AttributeType=S \
      --key-schema AttributeName=LockID,KeyType=HASH \
      --provisioned-throughput ReadCapacityUnits=1,WriteCapacityUnits=1 \
      >/dev/null 2>&1 \
    || die "Ohhh man...! Unable to create lock table"
}


create_state_bucket
enable_bucket_versioning
create_lock_table


#==================================================================#
#              Delete any local terraform state                    #
#==================================================================#
echo "DEBUG: Clearing out terraform state ${TERRAFORM_PATH}/.terraform for terraform environment ${TERRAENV}"
rm -rf "${TERRAFORM_PATH}/.terraform"

#==================================================================#
#                          Init terraform                          #
#==================================================================#
INIT_OPTS=("-backend-config" "bucket=${STATE_BUCKET}"
              "-backend-config" "key=${STATE_FILENAME}"
              "-backend-config" "region=${AWS_DEFAULT_REGION}"
              "-backend-config" "encrypt=true"
              "-backend-config" "dynamodb_table=${TERRAFORMSTATELOCKFILE}")

echo "DEBUG: Initialising terraform."
echo "DEBUG: cd $TERRAFORM_PATH ; terraform init ${INIT_OPTS[@]}"

# Use plugin cache to supercharge this thing
export TF_PLUGIN_CACHE_DIR="$HOME/.terraform.d/plugin-cache"

cd $TERRAFORM_PATH ; terraform init ${INIT_OPTS[@]}


case "$ACTION" in
  plan)
  rm -rf $PLAN_PATH
  mkdir -p $PLAN_PATH
  echo "DEBUG: Running TERRAFORM PLAN: terraform plan ${VAR_ITEMS[@]} -out=${PLAN_PATH}/terraplan.tfplan"
  #terraform plan ${VAR_ITEMS[@]} -out="${PLAN_PATH}/terraplan.tfplan"
  terraform plan -var-file=${TERRAENV_CONFIG} -var-file=${TERRAENV_LAYER_CONFIG} -out="${PLAN_PATH}/terraplan.tfplan"
  ;;
  apply)
  echo "DEBUG: Running TERRAFORM APPLY: terraform apply -backup=- ${PLAN_PATH}/terraplan.tfplan"
  terraform apply -backup="-" ${PLAN_PATH}/terraplan.tfplan
  ;;
  destroy)
  echo "DEBUG: Running TERRAFORM DESTROY: terraform destroy ${VAR_ITEMS[@]}"
  #terraform destroy "${VAR_ITEMS}"
  #terraform destroy -var-file=${TERRAENV_CONFIG} -var-file=${TERRAENV_LAYER_CONFIG}
  terraform destroy -var-file=${TERRAENV_CONFIG} -var-file=${TERRAENV_LAYER_CONFIG}
  ;;
  # more action coming soon
esac

usage