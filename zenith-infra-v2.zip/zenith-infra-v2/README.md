# zenith-infra-v2
Zenith Infrastructure Repository

Infrastructure code for building environments (in AWS) - using terraform, remote storage/remote locking.   

***Infrastructure layers***:  
VPC  
EKS  
...  


Layer VPC:   
Sets up VPC, public/private and db subnets, gateways, NATs, route tables ans associations

Layer EKS:  
Sets up EKS claster with managed worker node groups (creating two namespaces (DEV and SIT)) 

---
***Before you run the script:***    
(There is a 'terraform user' set up in AWS and those credentrilas should be used when running this script)  
Configure your AWS CLI:  
```aws configure```   
Test by running:  
```aws sts get-caller-identity```  
  
  
Set **AWS CLI** environment variables:  
To authenticate to AWS on the CLI is to set your Keys, AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY:  

```export AWS_ACCESS_KEY_ID=youraccesskey```  

```export AWS_SECRET_ACCESS_KEY=yoursecret```  

Set region:  
```export AWS_DEFAULT_REGION=thedefaultregion```  

 --- 

 ***Run the script (Please make sure you have configured and installed the necessary tools):***  
Go to tf directory and run (where tf.sh is located):  
To create a plan:   
```./tf.sh zenith nonprod vpc plan```  
```./tf.sh zenith nonprod eks plan```   
To apply the plan:  
```./tf.sh zenith nonprod vpc apply```   
```./tf.sh zenith nonprod eks apply```   
To destroy the resources:  
```./tf.sh zenith nonprod vpc destroy```   
```./tf.sh zenith nonprod eks destroy```    
where  
zenith - is the project name  (zenith)  
nonprod - the environment group  (nonprod or prod)     
vpc - the layer  (vpc, eks, ...)  
plan - the action (plan, apply, destroy, ...)   

 ---

***Prerequisities***:  
   AWS CLI >= 1.18.17  
   To interact with ***EKS Cluster***, please see Install section for details.   

 ---

***Install (To be able to use kubectl)***:  
To be able to interact with the EKS cluster using kubectl, install:  
```kubectl version --short --client```  
AWS IAM Authenticator for Kubernetes   
(Your system's Python version must be 2.7.9 or later.   
Otherwise, you receive hostname doesn't match errors with AWS CLI calls to Amazon EKS.)  
```aws-iam-authenticator help```  
(Follow instruction on: https://docs.aws.amazon.com/eks/latest/userguide/install-aws-iam-authenticator.html) 


***Kubeconfig***:  
Check if your profile has been set up and it is the correct one:  
```aws sts get-caller-identity```  
Run the following command:  
```aws eks --region region-code update-kubeconfig --name cluster_name```  
Test your configuration:  
```kubectl get svc```  
Create kubeconfig file:  
Create the default ~/.kube directory if it does not already exist:  
```mkdir -p ~/.kube```   
```cd eks```  
(If you have build built the infrastructure and you have the terra file, you can do the below)   
```terraform output kubeconfig > ~/.kube/config-nonprod```  
(Else you could go to AWS consle, S3 bucket, find the terra state file and copy the kube konfig from there)   
Add the above file to KUBECONFIG env variable:  
```export KUBECONFIG=$KUBECONFIG:~/.kube/config-nonprod```   
Test your configuration:  
```kubectl get svc```   
...

---  

***TODO***:  
**marked: # TODO**     
Use as modules  
Tag resources    
